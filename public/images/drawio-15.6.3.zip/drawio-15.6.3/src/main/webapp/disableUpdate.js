module.exports = {
	disableUpdate: function() 
	{
		return false;
	}
}