# To make pako.min.js work with IE11

1. Get release from https://github.com/nodeca/pako/releases
2. Copy dist/pako.es5.min.js to pako.min.js
